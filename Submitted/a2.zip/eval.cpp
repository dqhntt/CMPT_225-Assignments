#include "Scanner.h"
#include "Stack.h" // GENERIC STACK
#include <cassert>
#include <iostream>

namespace {
//  Pre:  `op` is one of these 4 math operators: { + - * / }
// Post:  Returns token with the result of [lhs] [op] [rhs]
Token compute(const Token& lhs, const Token& rhs, TokenType op) {
    int result = -1;
    switch (op) {
    case pltok:
        result = lhs.val + rhs.val;
        break;
    case mitok:
        result = lhs.val - rhs.val;
        break;
    case asttok:
        result = lhs.val * rhs.val;
        break;
    case slashtok:
        result = lhs.val / rhs.val;
        break;
    default:
        throw std::invalid_argument("Invalid operator");
    }
    return { integer, std::to_string(result), result };
}

// Pre:  numstack has 2 or more tokens.
//       opstack has 1 or more tokens.
Token popAndCompute(Stack<Token>& numstack, Stack<Token>& opstack) {
    assert(!numstack.isEmpty());
    const Token rhs = numstack.pop();

    assert(!numstack.isEmpty());
    const Token lhs = numstack.pop();

    assert(!opstack.isEmpty());
    const TokenType topOp = opstack.pop().tt;

    return compute(lhs, rhs, topOp);
}
} // namespace

int main() {
    Scanner scanner(std::cin);
    Stack<Token> numstack, opstack; // 2x Stacks of type Token
    Token currToken = scanner.getnext();

    while (currToken.tt != eof || !opstack.isEmpty()) {
        if (currToken.tt == integer) {
            numstack.push(std::move(currToken));
            currToken = scanner.getnext();
        } else if (currToken.tt == lptok) {
            opstack.push(std::move(currToken));
            currToken = scanner.getnext();
        } else if (currToken.tt == rptok) {
            if (opstack.peek().tt == lptok) {
                opstack.pop();
                currToken = scanner.getnext();
            } else {
                numstack.push(popAndCompute(numstack, opstack));
            }
        } else if (currToken.tt == pltok || currToken.tt == mitok || currToken.tt == eof) {
            const TokenType topOp = !opstack.isEmpty() ? opstack.peek().tt : errtok;
            if (!opstack.isEmpty()
                && (topOp == pltok || topOp == mitok || topOp == asttok || topOp == slashtok)) {
                numstack.push(popAndCompute(numstack, opstack));
            } else {
                opstack.push(std::move(currToken));
                currToken = scanner.getnext();
            }
        } else if (currToken.tt == asttok || currToken.tt == slashtok) {
            const TokenType topOp = !opstack.isEmpty() ? opstack.peek().tt : errtok;
            if (!opstack.isEmpty() && (topOp == asttok || topOp == slashtok)) {
                numstack.push(popAndCompute(numstack, opstack));
            } else {
                opstack.push(std::move(currToken));
                currToken = scanner.getnext();
            }
        }
    } // while

    std::cout << numstack.pop().val << std::endl;
}
